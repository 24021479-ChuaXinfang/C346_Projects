import React from 'react';
import {View, Text, Image} from 'react-native';
import FontAwesome6 from '@expo/vector-icons/FontAwesome6';

// Pass in necessary paremeters into Boat function
const Boat = ({name, description, picture}) => {
    return (
        <View>
            {/* Change codes below to display require content */}
            <Text style={{color:'dimgray', fontSize:25, fontWeight:'bold'}}>
                <FontAwesome6 name="sailboat" size={24} color="dimgray" /> {name}
            </Text>
            <Text style={{color:'gray', fontSize:15}}>
                {description}
            </Text>
            <Image source={picture} style={{width:500, height: 300}} />
            <Text></Text>
        </View>
    );
};

export default Boat;